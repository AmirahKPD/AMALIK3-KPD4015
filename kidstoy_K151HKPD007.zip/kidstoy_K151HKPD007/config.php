<?php 
$connect=mysqli_connect("localhost:3306", "root","","barang") or die("failed...");
// gagal sambung ke pangkalan data kerana password salah
?>
